/** @param {NS} ns */
export async function main(ns) {
  ns.print("1. Use the scp command to copy our  to each server. \n 2. Use the connect command to connect to a server.\n 3. Use the run command to run the NUKE.exe program and gain root access.\n 4. Use the run command again to run our .\n 5. Repeat steps 2-4 for each server.")
}